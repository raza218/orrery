/* ============================================================
   sky.js — the view through the aperture.
   Five scenes, all drawn procedurally so the app ships no video.
   ============================================================ */

export const SCENES = [
  { id: 'nebula', label: 'Nebula', coords: 'NGC 7000 · 20h59m · +44°31' },
  { id: 'flare', label: 'Solar Flare', coords: 'SOL · AR3697 · X1.2 CLASS' },
  { id: 'void', label: 'Deep Void', coords: 'BOÖTES VOID · 14h50m · +46°' },
  { id: 'meteor', label: 'Meteor Shower', coords: 'PERSEIDS · ZHR 96 · +58°' },
  { id: 'aurora', label: 'Aurora Orbit', coords: 'LEO 408KM · INC 51.6°' },
];

const PALETTES = {
  nebula: ['#0a0620', '#2b1054', '#7a2b6b'],
  flare: ['#12060a', '#4a1608', '#c25415'],
  void: ['#01020a', '#050a18', '#0a1024'],
  meteor: ['#04060f', '#0a1430', '#16305c'],
  aurora: ['#02040e', '#062028', '#0d4a48'],
};

const rand = (min, max) => min + Math.random() * (max - min);

export class Sky {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.scene = 'nebula';
    this.t = 0;
    this.running = false;
    this.reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    this.resize = this.resize.bind(this);
    this.frame = this.frame.bind(this);
    window.addEventListener('resize', this.resize);
    this.resize();
  }

  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const { clientWidth: w, clientHeight: h } = this.canvas;
    this.canvas.width = w * dpr;
    this.canvas.height = h * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.w = w;
    this.h = h;
    this.seed();
  }

  seed() {
    const density = Math.round((this.w * this.h) / 5200);
    this.stars = Array.from({ length: density }, () => ({
      x: Math.random() * this.w,
      y: Math.random() * this.h,
      r: rand(0.3, 1.5),
      depth: rand(0.15, 1),
      phase: Math.random() * Math.PI * 2,
    }));

    this.clouds = Array.from({ length: 7 }, () => ({
      x: Math.random() * this.w,
      y: Math.random() * this.h,
      r: rand(this.w * 0.18, this.w * 0.42),
      drift: rand(-0.06, 0.06),
      hue: rand(0, 1),
    }));

    this.meteors = [];
  }

  setScene(id) {
    if (!PALETTES[id]) return;
    this.scene = id;
    this.meteors = [];
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.frame();
  }

  stop() {
    this.running = false;
    cancelAnimationFrame(this.raf);
  }

  frame() {
    if (!this.running) return;
    this.t += this.reduced ? 0 : 1;
    this.draw();
    this.raf = requestAnimationFrame(this.frame);
  }

  draw() {
    const { ctx, w, h, t } = this;
    const [deep, mid, hot] = PALETTES[this.scene];

    const bg = ctx.createLinearGradient(0, 0, w * 0.4, h);
    bg.addColorStop(0, deep);
    bg.addColorStop(1, this.scene === 'void' ? deep : mid);
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    if (this.scene === 'nebula') this.drawClouds(mid, hot, 0.3);
    if (this.scene === 'aurora') this.drawAurora(hot);
    if (this.scene === 'flare') this.drawStar(hot, mid);

    this.drawStars();

    if (this.scene === 'meteor') this.drawMeteors();
    if (this.scene === 'aurora') this.drawLimb();

    // Faint aperture glass: a slow highlight sweep across the whole view.
    if (!this.reduced) {
      const gx = ((t * 0.3) % (w * 2)) - w * 0.5;
      const glass = ctx.createLinearGradient(gx, 0, gx + w * 0.5, h);
      glass.addColorStop(0, 'rgba(255,255,255,0)');
      glass.addColorStop(0.5, 'rgba(255,255,255,0.014)');
      glass.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = glass;
      ctx.fillRect(0, 0, w, h);
    }
  }

  drawStars() {
    const { ctx, t } = this;
    ctx.save();
    for (const s of this.stars) {
      const twinkle = 0.55 + 0.45 * Math.sin(t * 0.02 * s.depth + s.phase);
      ctx.globalAlpha = twinkle * s.depth;
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      // Slow parallax drift, deeper stars move less.
      const x = (s.x + t * 0.02 * s.depth) % this.w;
      ctx.arc(x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  drawClouds(mid, hot, alpha) {
    const { ctx, t } = this;
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (const c of this.clouds) {
      const x = (c.x + t * c.drift + this.w) % (this.w + c.r) - c.r / 2;
      const y = c.y + Math.sin(t * 0.002 + c.hue * 6) * 18;
      const g = ctx.createRadialGradient(x, y, 0, x, y, c.r);
      g.addColorStop(0, `${c.hue > 0.5 ? hot : mid}${Math.round(alpha * 90).toString(16)}`);
      g.addColorStop(1, 'transparent');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, c.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  drawStar(hot, mid) {
    // A limb of the sun in the lower-left corner, with a breathing corona.
    const { ctx, w, h, t } = this;
    const cx = w * 0.16;
    const cy = h * 1.02;
    const r = Math.max(w, h) * 0.34;
    const pulse = 1 + Math.sin(t * 0.012) * 0.05;

    const corona = ctx.createRadialGradient(cx, cy, r * 0.7, cx, cy, r * 2.1 * pulse);
    corona.addColorStop(0, 'rgba(255,168,64,0.5)');
    corona.addColorStop(0.4, 'rgba(194,84,21,0.22)');
    corona.addColorStop(1, 'transparent');
    ctx.fillStyle = corona;
    ctx.fillRect(0, 0, w, h);

    const disc = ctx.createRadialGradient(cx, cy - r * 0.3, r * 0.2, cx, cy, r);
    disc.addColorStop(0, '#fff3d6');
    disc.addColorStop(0.6, hot);
    disc.addColorStop(1, mid);
    ctx.fillStyle = disc;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();
  }

  drawAurora(hot) {
    const { ctx, w, h, t } = this;
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (let band = 0; band < 3; band += 1) {
      ctx.beginPath();
      const baseY = h * (0.52 + band * 0.09);
      ctx.moveTo(0, h);
      for (let x = 0; x <= w; x += 12) {
        const y =
          baseY +
          Math.sin(x * 0.006 + t * 0.008 + band) * 26 +
          Math.sin(x * 0.017 - t * 0.004 + band * 2) * 12;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(w, h);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, baseY - 60, 0, h);
      g.addColorStop(0, 'rgba(120,255,214,0)');
      g.addColorStop(0.35, band === 1 ? 'rgba(154,140,255,0.16)' : 'rgba(87,217,206,0.15)');
      g.addColorStop(1, 'rgba(2,20,26,0)');
      ctx.fillStyle = g;
      ctx.fill();
    }
    ctx.restore();
    void hot;
  }

  drawLimb() {
    // The curve of a planet across the bottom edge.
    const { ctx, w, h } = this;
    const r = w * 1.15;
    const cx = w / 2;
    const cy = h + r - h * 0.16;

    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = '#03060d';
    ctx.fill();

    ctx.beginPath();
    ctx.arc(cx, cy, r, Math.PI, 0);
    ctx.strokeStyle = 'rgba(87,217,206,0.55)';
    ctx.lineWidth = 2;
    ctx.stroke();

    const halo = ctx.createRadialGradient(cx, cy, r, cx, cy, r + 90);
    halo.addColorStop(0, 'rgba(87,217,206,0.22)');
    halo.addColorStop(1, 'transparent');
    ctx.fillStyle = halo;
    ctx.beginPath();
    ctx.arc(cx, cy, r + 90, Math.PI, 0);
    ctx.fill();
    ctx.restore();
  }

  drawMeteors() {
    const { ctx, w, h } = this;

    if (!this.reduced && Math.random() < 0.035) {
      this.meteors.push({
        x: rand(-w * 0.2, w),
        y: rand(-40, h * 0.5),
        len: rand(90, 260),
        speed: rand(7, 15),
        life: 1,
      });
    }

    ctx.save();
    ctx.lineCap = 'round';
    for (const m of this.meteors) {
      const g = ctx.createLinearGradient(m.x, m.y, m.x - m.len, m.y - m.len * 0.42);
      g.addColorStop(0, `rgba(255,255,255,${m.life})`);
      g.addColorStop(0.35, `rgba(140,190,255,${m.life * 0.4})`);
      g.addColorStop(1, 'transparent');
      ctx.strokeStyle = g;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(m.x, m.y);
      ctx.lineTo(m.x - m.len, m.y - m.len * 0.42);
      ctx.stroke();

      m.x += m.speed;
      m.y += m.speed * 0.42;
      m.life -= 0.008;
    }
    this.meteors = this.meteors.filter((m) => m.life > 0 && m.x - m.len < w + 200);
    ctx.restore();
  }

  destroy() {
    this.stop();
    window.removeEventListener('resize', this.resize);
  }
}
