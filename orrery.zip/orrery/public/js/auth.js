import { api } from './api.js';
import { Sky, SCENES } from './sky.js';

/* Background: pick a scene at random so the airlock is never the same twice. */
const sky = new Sky(document.getElementById('sky-bg'));
sky.setScene(SCENES[Math.floor(Math.random() * SCENES.length)].id);
sky.start();

/* If a session cookie is still valid, skip the form entirely. */
api.get('/auth/me')
  .then(() => { window.location.href = '/observatory.html'; })
  .catch(() => {});

const views = {
  login: document.getElementById('view-login'),
  signup: document.getElementById('view-signup'),
};

function show(name) {
  views.login.hidden = name !== 'login';
  views.signup.hidden = name !== 'signup';
  document.querySelectorAll('.notice').forEach((n) => { n.hidden = true; });
  const first = views[name].querySelector('input');
  if (first) first.focus();
}

document.getElementById('to-signup').addEventListener('click', () => show('signup'));
document.getElementById('to-login').addEventListener('click', () => show('login'));

function fail(box, message) {
  box.textContent = message;
  box.hidden = false;
}

async function submit(form, box, run) {
  const button = form.querySelector('button[type=submit]');
  const original = button.textContent;
  box.hidden = true;
  button.disabled = true;
  button.textContent = 'Aligning…';

  try {
    await run(Object.fromEntries(new FormData(form)));
    window.location.href = '/observatory.html';
  } catch (err) {
    fail(box, err.message);
    button.disabled = false;
    button.textContent = original;
  }
}

document.getElementById('form-login').addEventListener('submit', (e) => {
  e.preventDefault();
  const box = document.getElementById('login-error');
  submit(e.target, box, (body) => {
    if (!body.identifier?.trim() || !body.password) {
      throw new Error('Enter your call sign and password.');
    }
    return api.post('/auth/login', body);
  });
});

document.getElementById('form-signup').addEventListener('submit', (e) => {
  e.preventDefault();
  const box = document.getElementById('signup-error');
  submit(e.target, box, (body) => {
    if (body.password.length < 8) throw new Error('Use a password of at least 8 characters.');
    return api.post('/auth/signup', body);
  });
});
