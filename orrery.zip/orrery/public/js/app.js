import { api } from './api.js';
import { Sky, SCENES } from './sky.js';
import { Ambience } from './ambience.js';

const $ = (sel) => document.querySelector(sel);
const RANKS = [
  'Cadet', 'Observer', 'Navigator', 'Astronomer', 'Cartographer',
  'Astrographer', 'Commander', 'Voyager', 'Archivist of Stars',
];
const totalXpForLevel = (level) => 50 * level * (level - 1);

const state = { user: null, missions: [], notes: [] };

/* ============================================================
   Boot
   ============================================================ */

const sky = new Sky($('#sky'));
const ambience = new Ambience();
sky.start();

try {
  const { user } = await api.get('/auth/me');
  state.user = user;
} catch {
  window.location.replace('/');
  throw new Error('not signed in');
}

applyPreferences();
paintRank();
paintAccount();
buildScenes();
await Promise.all([loadMissions(), loadNotes(), loadStats()]);

/* ============================================================
   Panels
   ============================================================ */

const tools = document.querySelectorAll('.tool');

function openPanel(name) {
  tools.forEach((t) => t.setAttribute('aria-selected', String(t.dataset.panel === name)));
  document.querySelectorAll('.panel').forEach((p) => {
    p.hidden = p.id !== `panel-${name}`;
  });
  if (name === 'stats') loadStats();
}

function closePanels() {
  tools.forEach((t) => t.setAttribute('aria-selected', 'false'));
  document.querySelectorAll('.panel').forEach((p) => { p.hidden = true; });
}

tools.forEach((tool) => {
  tool.addEventListener('click', () => {
    const isOpen = tool.getAttribute('aria-selected') === 'true';
    if (isOpen) closePanels();
    else openPanel(tool.dataset.panel);
  });
});

document.querySelectorAll('.panel__close').forEach((b) => b.addEventListener('click', closePanels));

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closePanels();
  if (e.key === ' ' && e.target === document.body) {
    e.preventDefault();
    timer.toggle();
  }
});

/* ============================================================
   Toasts
   ============================================================ */

function toast(message, kind = '') {
  const el = document.createElement('div');
  el.className = `toast ${kind ? `toast--${kind}` : ''}`;
  el.textContent = message;
  $('#toasts').append(el);
  setTimeout(() => el.remove(), 3600);
}

/* ============================================================
   Scenes and sound
   ============================================================ */

function buildScenes() {
  const wrap = $('#scenes');
  SCENES.forEach((scene) => {
    const b = document.createElement('button');
    b.className = 'scene-btn';
    b.textContent = scene.label;
    b.setAttribute('aria-pressed', String(scene.id === state.user.preferences.scene));
    b.addEventListener('click', () => setScene(scene.id));
    wrap.append(b);
  });
}

function setScene(id) {
  const scene = SCENES.find((s) => s.id === id) || SCENES[0];
  state.user.preferences.scene = scene.id;
  sky.setScene(scene.id);
  ambience.currentScene = scene.id;
  ambience.setScene(scene.id);
  $('#coords').textContent = scene.coords;
  document.querySelectorAll('.scene-btn').forEach((b, i) => {
    b.setAttribute('aria-pressed', String(SCENES[i].id === scene.id));
  });
  savePreferences();
}

$('#btn-sound').addEventListener('click', async () => {
  const on = await ambience.toggle();
  $('#btn-sound').setAttribute('aria-pressed', String(on));
  $('#wave').style.opacity = on ? '1' : '0.25';
  state.user.preferences.soundOn = on;
  savePreferences();
});

let prefTimer;
function savePreferences() {
  clearTimeout(prefTimer);
  prefTimer = setTimeout(() => {
    api.patch('/auth/preferences', state.user.preferences).catch(() => {});
  }, 600);
}

function applyPreferences() {
  const p = state.user.preferences;
  sky.setScene(p.scene);
  ambience.currentScene = p.scene;
  const scene = SCENES.find((s) => s.id === p.scene) || SCENES[0];
  $('#coords').textContent = scene.coords;
  $('#study-min').textContent = p.studyMinutes;
  $('#break-min').textContent = p.breakMinutes;
  $('#wave').style.opacity = '0.25';
}

/* ============================================================
   The orrery timer
   ============================================================ */

const CIRCUMFERENCE = 2 * Math.PI * 93;

const timer = {
  mode: 'study',
  remaining: state.user.preferences.studyMinutes * 60,
  running: false,
  handle: null,

  get total() {
    const p = state.user.preferences;
    return (this.mode === 'study' ? p.studyMinutes : p.breakMinutes) * 60;
  },

  toggle() {
    if (this.running) this.pause();
    else this.start();
  },

  start() {
    if (this.running) return;
    this.running = true;
    $('#btn-start').textContent = 'Pause';
    this.handle = setInterval(() => this.tick(), 1000);
  },

  pause() {
    this.running = false;
    $('#btn-start').textContent = 'Resume';
    clearInterval(this.handle);
  },

  reset() {
    this.pause();
    this.remaining = this.total;
    $('#btn-start').textContent = 'Start';
    this.paint();
  },

  setMode(mode) {
    this.mode = mode;
    $('#orrery').classList.toggle('is-break', mode === 'break');
    $('#mode-label').textContent = mode === 'study' ? 'Study' : 'Break';
    this.remaining = this.total;
    this.paint();
  },

  tick() {
    this.remaining -= 1;
    if (this.remaining <= 0) return this.complete();
    return this.paint();
  },

  async complete() {
    this.pause();
    const finished = this.mode;

    if (finished === 'study') {
      const minutes = state.user.preferences.studyMinutes;
      try {
        const res = await api.post('/sessions', { minutes, scene: state.user.preferences.scene });
        state.user = { ...state.user, ...res.progress };
        paintRank();
        paintAccount();
        toast(`Session logged · +${res.awarded} XP`, 'xp');
        if (res.levelUp) toast(`Promoted to ${res.progress.rank}`, 'xp');
      } catch (err) {
        toast(err.message, 'bad');
      }
      this.setMode('break');
      this.start();
    } else {
      toast('Break over. The sky is still there.');
      this.setMode('study');
    }
    $('#btn-start').textContent = this.running ? 'Pause' : 'Start';
  },

  paint() {
    const mm = String(Math.floor(this.remaining / 60)).padStart(2, '0');
    const ss = String(this.remaining % 60).padStart(2, '0');
    $('.orrery__clock').textContent = `${mm}:${ss}`;

    const done = 1 - this.remaining / this.total;
    $('#track').setAttribute('stroke-dashoffset', String(CIRCUMFERENCE * (1 - done)));
    $('#orbiter').setAttribute('transform', `rotate(${done * 360} 111 111)`);
    document.title = this.running ? `${mm}:${ss} · Orrery` : 'Orrery — observatory';
  },
};

timer.paint();

$('#btn-start').addEventListener('click', () => timer.toggle());
$('#btn-reset').addEventListener('click', () => timer.reset());

document.querySelectorAll('[data-step]').forEach((btn) => {
  btn.addEventListener('click', () => {
    const key = btn.dataset.step === 'study' ? 'studyMinutes' : 'breakMinutes';
    const cap = btn.dataset.step === 'study' ? 180 : 60;
    const next = Math.min(cap, Math.max(1, state.user.preferences[key] + Number(btn.dataset.by)));
    state.user.preferences[key] = next;
    $(btn.dataset.step === 'study' ? '#study-min' : '#break-min').textContent = next;
    savePreferences();
    if (!timer.running) timer.reset();
  });
});

/* ============================================================
   Missions
   ============================================================ */

async function loadMissions() {
  const { missions } = await api.get('/missions');
  state.missions = missions;
  paintMissions();
}

function paintMissions() {
  const list = $('#mission-list');
  list.innerHTML = '';

  if (!state.missions.length) {
    list.innerHTML =
      '<li class="empty">No missions yet.<br />Add the one thing this session is for.</li>';
    return;
  }

  state.missions.forEach((m) => {
    const li = document.createElement('li');
    li.className = `mission ${m.completed ? 'is-done' : ''}`;
    li.innerHTML = `
      <button class="mission__check" aria-label="Toggle complete">✓</button>
      <span class="mission__title"></span>
      <span class="tag tag--${m.difficulty}">${m.xpValue} xp</span>
      <button class="mission__drop" aria-label="Delete mission">×</button>`;
    li.querySelector('.mission__title').textContent = m.title;

    li.querySelector('.mission__check').addEventListener('click', () => toggleMission(m));
    li.querySelector('.mission__drop').addEventListener('click', () => dropMission(m));
    list.append(li);
  });
}

async function toggleMission(mission) {
  try {
    const res = await api.patch(`/missions/${mission._id}`, { completed: !mission.completed });
    Object.assign(mission, res.mission);
    state.user = { ...state.user, ...res.progress };
    paintMissions();
    paintRank();
    paintAccount();
    if (res.awarded > 0) toast(`Mission cleared · +${res.awarded} XP`, 'xp');
    if (res.levelUp) toast(`Promoted to ${res.progress.rank}`, 'xp');
  } catch (err) {
    toast(err.message, 'bad');
  }
}

async function dropMission(mission) {
  try {
    await api.del(`/missions/${mission._id}`);
    state.missions = state.missions.filter((m) => m._id !== mission._id);
    paintMissions();
  } catch (err) {
    toast(err.message, 'bad');
  }
}

$('#form-mission').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = $('#mission-title');
  const title = input.value.trim();
  if (!title) return;

  try {
    const { mission } = await api.post('/missions', {
      title,
      difficulty: $('#mission-difficulty').value,
    });
    state.missions.unshift(mission);
    input.value = '';
    paintMissions();
  } catch (err) {
    toast(err.message, 'bad');
  }
});

/* ============================================================
   Stats
   ============================================================ */

async function loadStats() {
  let stats;
  try {
    stats = await api.get('/sessions/stats');
  } catch {
    return;
  }

  const hours = Math.floor(stats.totalMinutes / 60);
  const mins = stats.totalMinutes % 60;
  $('#s-hours').textContent = hours ? `${hours}h ${mins}m` : `${mins}m`;
  $('#s-sessions').textContent = stats.totalSessions;
  $('#s-missions').textContent = stats.missionsCompleted;
  $('#s-streak').textContent = stats.streak;

  const peak = Math.max(30, ...stats.days.map((d) => d.minutes));
  const chart = $('#chart');
  chart.innerHTML = '';
  stats.days.forEach((day) => {
    const bar = document.createElement('div');
    bar.className = `chart__bar ${day.minutes ? '' : 'is-empty'}`;
    bar.style.height = `${Math.max(3, (day.minutes / peak) * 100)}%`;
    bar.title = `${day.date} · ${day.minutes} min`;
    chart.append(bar);
  });

  const from = new Date(stats.days[0].date);
  $('#axis-from').textContent = from.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

/* ============================================================
   Rank
   ============================================================ */

function paintRank() {
  const u = state.user;
  $('#hud-rank').textContent = u.rank;
  $('#hud-xp').textContent = `${u.xp} XP`;
  $('#lv-number').textContent = u.level;
  $('#lv-rank').textContent = u.rank;
  $('#lv-bar').style.width = `${Math.min(100, u.percent)}%`;
  $('#lv-into').textContent = `${u.xpIntoLevel} / ${u.xpForNextLevel} XP`;
  $('#lv-need').textContent = `${u.xpForNextLevel - u.xpIntoLevel} to next`;

  const ladder = $('#ladder');
  ladder.innerHTML = '';
  RANKS.forEach((rank, i) => {
    const level = i + 1;
    const li = document.createElement('li');
    if (level === u.level) li.className = 'is-current';
    else if (level < u.level) li.className = 'is-passed';
    li.innerHTML = `<span>${level}. ${rank}</span><span class="readout">${totalXpForLevel(level)} XP</span>`;
    ladder.append(li);
  });
}

/* ============================================================
   Observation log — notes pinned to the sky
   ============================================================ */

const TINTS = ['amber', 'cyan', 'violet'];

async function loadNotes() {
  const { entries } = await api.get('/logs');
  state.notes = entries;
  paintNotes();
}

function paintNotes() {
  const board = $('#log-board');
  board.innerHTML = '';
  state.notes.forEach((note) => board.append(buildNote(note)));

  const index = $('#note-index');
  index.innerHTML = '';
  state.notes.forEach((note, i) => {
    const li = document.createElement('li');
    const preview = (note.body || 'Empty note').slice(0, 28);
    li.innerHTML = `<span>${i + 1}. ${preview}</span>`;
    index.append(li);
  });
}

function buildNote(note) {
  const el = document.createElement('article');
  el.className = `log-note log-note--${note.tint}`;
  el.style.left = `${note.x}px`;
  el.style.top = `${note.y}px`;
  el.innerHTML = `
    <div class="log-note__bar">
      <span class="log-note__date"></span>
      <button class="log-note__drop" aria-label="Delete note">×</button>
    </div>
    <textarea placeholder="What did you see?"></textarea>`;

  el.querySelector('.log-note__date').textContent = new Date(note.createdAt)
    .toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
    .toUpperCase();

  const area = el.querySelector('textarea');
  area.value = note.body;

  let saveTimer;
  area.addEventListener('input', () => {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      api.patch(`/logs/${note._id}`, { body: area.value }).catch((e) => toast(e.message, 'bad'));
      note.body = area.value;
    }, 700);
  });

  el.querySelector('.log-note__drop').addEventListener('click', async () => {
    try {
      await api.del(`/logs/${note._id}`);
      state.notes = state.notes.filter((n) => n._id !== note._id);
      paintNotes();
    } catch (err) {
      toast(err.message, 'bad');
    }
  });

  makeDraggable(el, note);
  return el;
}

function makeDraggable(el, note) {
  const bar = el.querySelector('.log-note__bar');

  bar.addEventListener('pointerdown', (e) => {
    if (e.target.closest('button')) return;
    const startX = e.clientX - note.x;
    const startY = e.clientY - note.y;
    el.classList.add('is-dragging');
    bar.setPointerCapture(e.pointerId);

    const move = (ev) => {
      note.x = Math.max(0, ev.clientX - startX);
      note.y = Math.max(0, ev.clientY - startY);
      el.style.left = `${note.x}px`;
      el.style.top = `${note.y}px`;
    };

    const up = () => {
      el.classList.remove('is-dragging');
      bar.removeEventListener('pointermove', move);
      bar.removeEventListener('pointerup', up);
      api.patch(`/logs/${note._id}`, { x: note.x, y: note.y }).catch(() => {});
    };

    bar.addEventListener('pointermove', move);
    bar.addEventListener('pointerup', up);
  });
}

$('#btn-note').addEventListener('click', async () => {
  try {
    const { entry } = await api.post('/logs', {
      tint: TINTS[state.notes.length % TINTS.length],
      x: 140 + ((state.notes.length * 26) % 220),
      y: 120 + ((state.notes.length * 22) % 180),
    });
    state.notes.push(entry);
    paintNotes();
  } catch (err) {
    toast(err.message, 'bad');
  }
});

/* ============================================================
   Account
   ============================================================ */

function paintAccount() {
  $('#a-user').textContent = state.user.username;
  $('#a-mail').textContent = state.user.email;
  $('#a-xp').textContent = `${state.user.xp} XP`;
  $('#a-since').textContent = new Date(state.user.memberSince).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

$('#btn-signout').addEventListener('click', async () => {
  await api.post('/auth/logout').catch(() => {});
  window.location.href = '/';
});

$('#btn-delete').addEventListener('click', async () => {
  const box = $('#delete-error');
  const password = $('#delete-pw').value;
  box.hidden = true;

  if (!password) {
    box.textContent = 'Enter your password to confirm.';
    box.hidden = false;
    return;
  }

  const sure = window.confirm(
    `Delete ${state.user.username} and all of its missions, notes and sessions? This cannot be undone.`
  );
  if (!sure) return;

  try {
    await api.del('/auth/account', { password });
    window.location.href = '/';
  } catch (err) {
    box.textContent = err.message;
    box.hidden = false;
  }
});

/* Restore ambient sound only after a gesture — browsers require one. */
if (state.user.preferences.soundOn) {
  const wake = async () => {
    await ambience.enable();
    $('#btn-sound').setAttribute('aria-pressed', 'true');
    $('#wave').style.opacity = '1';
    document.removeEventListener('pointerdown', wake);
  };
  document.addEventListener('pointerdown', wake, { once: true });
}
