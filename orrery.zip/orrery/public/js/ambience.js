/* Procedural ambience: filtered noise plus a low drone, tuned per scene.
   Built on the Web Audio API so the app carries no sound files. */

const PROFILES = {
  nebula: { cutoff: 420, drone: 58, gain: 0.05, q: 1.2 },
  flare: { cutoff: 900, drone: 44, gain: 0.07, q: 0.8 },
  void: { cutoff: 220, drone: 36, gain: 0.035, q: 2 },
  meteor: { cutoff: 640, drone: 52, gain: 0.045, q: 1.5 },
  aurora: { cutoff: 520, drone: 66, gain: 0.05, q: 3 },
};

export class Ambience {
  constructor() {
    this.ctx = null;
    this.on = false;
  }

  build() {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    this.ctx = new Ctx();

    // Two seconds of looping pink-ish noise.
    const frames = this.ctx.sampleRate * 2;
    const buffer = this.ctx.createBuffer(1, frames, this.ctx.sampleRate);
    const channel = buffer.getChannelData(0);
    let last = 0;
    for (let i = 0; i < frames; i += 1) {
      const white = Math.random() * 2 - 1;
      last = (last + 0.02 * white) / 1.02;
      channel[i] = last * 3.5;
    }

    this.noise = this.ctx.createBufferSource();
    this.noise.buffer = buffer;
    this.noise.loop = true;

    this.filter = this.ctx.createBiquadFilter();
    this.filter.type = 'lowpass';

    this.drone = this.ctx.createOscillator();
    this.drone.type = 'sine';

    this.droneGain = this.ctx.createGain();
    this.droneGain.gain.value = 0.05;

    this.master = this.ctx.createGain();
    this.master.gain.value = 0;

    this.noise.connect(this.filter).connect(this.master);
    this.drone.connect(this.droneGain).connect(this.master);
    this.master.connect(this.ctx.destination);

    this.noise.start();
    this.drone.start();
  }

  ramp(param, value, seconds = 0.6) {
    param.cancelScheduledValues(this.ctx.currentTime);
    param.setTargetAtTime(value, this.ctx.currentTime, seconds / 3);
  }

  setScene(id) {
    this.profile = PROFILES[id] || PROFILES.nebula;
    if (!this.ctx) return;
    this.filter.frequency.value = this.profile.cutoff;
    this.filter.Q.value = this.profile.q;
    this.drone.frequency.value = this.profile.drone;
    if (this.on) this.ramp(this.master.gain, this.profile.gain);
  }

  async enable() {
    if (!this.ctx) this.build();
    await this.ctx.resume();
    this.on = true;
    this.setScene(this.currentScene || 'nebula');
    this.ramp(this.master.gain, (this.profile || PROFILES.nebula).gain);
  }

  disable() {
    this.on = false;
    if (this.ctx) this.ramp(this.master.gain, 0, 0.4);
  }

  async toggle() {
    if (this.on) this.disable();
    else await this.enable();
    return this.on;
  }
}
