const Mission = require('../models/Mission');
const User = require('../models/User');
const { asyncRoute } = require('../middleware/errorHandler');
const { progress, levelFromXp } = require('../utils/xp');

const list = asyncRoute(async (req, res) => {
  const missions = await Mission.find({ owner: req.session.userId }).sort({ completed: 1, createdAt: -1 });
  res.json({ missions });
});

const create = asyncRoute(async (req, res) => {
  const { title = '', difficulty = 'standard' } = req.body;
  if (!title.trim()) return res.status(400).json({ error: 'Give the mission a name.' });

  const mission = await Mission.create({
    owner: req.session.userId,
    title: title.trim(),
    difficulty,
  });
  res.status(201).json({ mission });
});

/** PATCH /api/missions/:id — toggling completion is what moves XP. */
const update = asyncRoute(async (req, res) => {
  const mission = await Mission.findOne({ _id: req.params.id, owner: req.session.userId });
  if (!mission) return res.status(404).json({ error: 'That mission no longer exists.' });

  const { title, difficulty, completed } = req.body;
  if (title !== undefined) mission.title = String(title).trim();
  if (difficulty !== undefined) mission.difficulty = difficulty;

  let award = 0;
  if (completed !== undefined && completed !== mission.completed) {
    mission.completed = Boolean(completed);
    mission.completedAt = mission.completed ? new Date() : null;
    award = mission.completed ? mission.xpValue : -mission.xpValue;
  }
  await mission.save();

  const user = await User.findById(req.session.userId);
  const levelBefore = levelFromXp(user.xp);
  user.xp = Math.max(0, user.xp + award);
  await user.save();

  res.json({
    mission,
    awarded: award,
    levelUp: levelFromXp(user.xp) > levelBefore,
    progress: progress(user.xp),
  });
});

const remove = asyncRoute(async (req, res) => {
  const mission = await Mission.findOneAndDelete({ _id: req.params.id, owner: req.session.userId });
  if (!mission) return res.status(404).json({ error: 'That mission no longer exists.' });
  res.json({ ok: true });
});

module.exports = { list, create, update, remove };
