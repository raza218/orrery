const User = require('../models/User');
const Mission = require('../models/Mission');
const LogEntry = require('../models/LogEntry');
const StudySession = require('../models/StudySession');
const { asyncRoute } = require('../middleware/errorHandler');
const { progress } = require('../utils/xp');

const shape = (user) => ({
  id: user._id,
  username: user.username,
  email: user.email,
  preferences: user.preferences,
  memberSince: user.createdAt,
  ...progress(user.xp),
});

/** POST /api/auth/signup — writes the observer to the database for good. */
const signup = asyncRoute(async (req, res) => {
  const { username = '', email = '', password = '' } = req.body;

  if (password.length < 8) {
    return res.status(400).json({ error: 'Use a password of at least 8 characters.' });
  }

  const user = new User({ username: username.trim(), email: email.trim() });
  await user.setPassword(password);
  await user.save();

  req.session.userId = user._id.toString();
  res.status(201).json({ user: shape(user) });
});

/** POST /api/auth/login — accepts either the call sign or the email address. */
const login = asyncRoute(async (req, res) => {
  const { identifier = '', password = '' } = req.body;
  const handle = identifier.trim();

  const user = await User.findOne({
    $or: [{ email: handle.toLowerCase() }, { username: handle }],
  })
    .collation({ locale: 'en', strength: 2 })
    .select('+passwordHash');

  // Same message either way, so the form cannot be used to enumerate accounts.
  const ok = user && (await user.verifyPassword(password));
  if (!ok) return res.status(401).json({ error: 'That call sign and password do not match.' });

  user.lastSeenAt = new Date();
  await user.save();

  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: 'Could not start a session. Try again.' });
    req.session.userId = user._id.toString();
    res.json({ user: shape(user) });
  });
});

/** GET /api/auth/me — rehydrates the app on reload. */
const me = asyncRoute(async (req, res) => {
  const user = await User.findById(req.session.userId);
  if (!user) {
    req.session.destroy(() => {});
    return res.status(401).json({ error: 'Sign in to continue.' });
  }
  res.json({ user: shape(user) });
});

/** PATCH /api/auth/preferences — scene, timer lengths, sound. */
const updatePreferences = asyncRoute(async (req, res) => {
  const { scene, studyMinutes, breakMinutes, soundOn } = req.body;
  const user = await User.findById(req.session.userId);
  if (!user) return res.status(401).json({ error: 'Sign in to continue.' });

  if (scene !== undefined) user.preferences.scene = scene;
  if (studyMinutes !== undefined) user.preferences.studyMinutes = Number(studyMinutes);
  if (breakMinutes !== undefined) user.preferences.breakMinutes = Number(breakMinutes);
  if (soundOn !== undefined) user.preferences.soundOn = Boolean(soundOn);

  await user.save();
  res.json({ user: shape(user) });
});

/** POST /api/auth/logout — ends the session, leaves the account untouched. */
const logout = (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('orrery.sid');
    res.json({ ok: true });
  });
};

/**
 * DELETE /api/auth/account — the only path that removes an observer.
 * Requires the current password, then erases the account and everything it owns.
 */
const deleteAccount = asyncRoute(async (req, res) => {
  const { password = '' } = req.body;
  const user = await User.findById(req.session.userId).select('+passwordHash');
  if (!user) return res.status(401).json({ error: 'Sign in to continue.' });

  const ok = await user.verifyPassword(password);
  if (!ok) return res.status(403).json({ error: 'Wrong password. The account was not deleted.' });

  const owner = user._id;
  await Promise.all([
    Mission.deleteMany({ owner }),
    LogEntry.deleteMany({ owner }),
    StudySession.deleteMany({ owner }),
  ]);
  await user.deleteOne();

  req.session.destroy(() => {
    res.clearCookie('orrery.sid');
    res.json({ ok: true, message: 'Account deleted.' });
  });
});

module.exports = { signup, login, me, updatePreferences, logout, deleteAccount };
