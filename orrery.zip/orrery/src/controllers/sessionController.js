const mongoose = require('mongoose');
const StudySession = require('../models/StudySession');
const User = require('../models/User');
const Mission = require('../models/Mission');
const { asyncRoute } = require('../middleware/errorHandler');
const { progress, levelFromXp } = require('../utils/xp');

const XP_PER_MINUTE = 2;

/** POST /api/sessions — called when a focus block runs to completion. */
const record = asyncRoute(async (req, res) => {
  const minutes = Math.round(Number(req.body.minutes));
  if (!Number.isFinite(minutes) || minutes < 1 || minutes > 180) {
    return res.status(400).json({ error: 'A session must be between 1 and 180 minutes.' });
  }

  const session = await StudySession.create({
    owner: req.session.userId,
    minutes,
    scene: req.body.scene || 'nebula',
  });

  const user = await User.findById(req.session.userId);
  const levelBefore = levelFromXp(user.xp);
  user.xp += minutes * XP_PER_MINUTE;
  await user.save();

  res.status(201).json({
    session,
    awarded: minutes * XP_PER_MINUTE,
    levelUp: levelFromXp(user.xp) > levelBefore,
    progress: progress(user.xp),
  });
});

/** GET /api/sessions/stats — totals, a 14-day series, and the current streak. */
const stats = asyncRoute(async (req, res) => {
  const owner = req.session.userId;
  const since = new Date();
  since.setDate(since.getDate() - 13);
  since.setHours(0, 0, 0, 0);

  const [sessions, totals, missionsDone] = await Promise.all([
    StudySession.find({ owner, endedAt: { $gte: since } }).sort({ endedAt: 1 }),
    StudySession.aggregate([
      { $match: { owner: new mongoose.Types.ObjectId(String(owner)) } },
      { $group: { _id: null, minutes: { $sum: '$minutes' }, count: { $sum: 1 } } },
    ]),
    Mission.countDocuments({ owner, completed: true }),
  ]);

  const days = [];
  for (let i = 13; i >= 0; i -= 1) {
    const day = new Date();
    day.setDate(day.getDate() - i);
    const key = day.toISOString().slice(0, 10);
    const minutes = sessions
      .filter((s) => s.endedAt.toISOString().slice(0, 10) === key)
      .reduce((sum, s) => sum + s.minutes, 0);
    days.push({ date: key, minutes });
  }

  // Count back from today. An empty today does not break a run that is still alive.
  let streak = 0;
  let cursor = days.length - 1;
  if (days[cursor].minutes === 0) cursor -= 1;
  for (; cursor >= 0 && days[cursor].minutes > 0; cursor -= 1) streak += 1;

  res.json({
    totalMinutes: totals[0]?.minutes || 0,
    totalSessions: totals[0]?.count || 0,
    missionsCompleted: missionsDone,
    streak,
    days,
  });
});

module.exports = { record, stats };
