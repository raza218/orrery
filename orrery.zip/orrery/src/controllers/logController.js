const LogEntry = require('../models/LogEntry');
const { asyncRoute } = require('../middleware/errorHandler');

const list = asyncRoute(async (req, res) => {
  const entries = await LogEntry.find({ owner: req.session.userId }).sort({ createdAt: 1 });
  res.json({ entries });
});

const create = asyncRoute(async (req, res) => {
  const { body = '', tint = 'amber', x = 40, y = 40 } = req.body;
  const entry = await LogEntry.create({ owner: req.session.userId, body, tint, x, y });
  res.status(201).json({ entry });
});

const update = asyncRoute(async (req, res) => {
  const fields = {};
  ['body', 'tint', 'x', 'y'].forEach((key) => {
    if (req.body[key] !== undefined) fields[key] = req.body[key];
  });

  const entry = await LogEntry.findOneAndUpdate(
    { _id: req.params.id, owner: req.session.userId },
    fields,
    { new: true, runValidators: true }
  );
  if (!entry) return res.status(404).json({ error: 'That log entry no longer exists.' });
  res.json({ entry });
});

const remove = asyncRoute(async (req, res) => {
  const entry = await LogEntry.findOneAndDelete({ _id: req.params.id, owner: req.session.userId });
  if (!entry) return res.status(404).json({ error: 'That log entry no longer exists.' });
  res.json({ ok: true });
});

module.exports = { list, create, update, remove };
