const router = require('express').Router();
const requireAuth = require('../middleware/requireAuth');

router.use('/auth', require('./auth.routes'));

// Everything below this line belongs to one observer and is gated.
router.use('/missions', requireAuth, require('./mission.routes'));
router.use('/logs', requireAuth, require('./log.routes'));
router.use('/sessions', requireAuth, require('./session.routes'));

router.get('/health', (req, res) => res.json({ ok: true, uptime: process.uptime() }));

module.exports = router;
