const router = require('express').Router();
const c = require('../controllers/sessionController');

router.get('/stats', c.stats);
router.post('/', c.record);

module.exports = router;
