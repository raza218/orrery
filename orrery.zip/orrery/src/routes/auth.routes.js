const router = require('express').Router();
const requireAuth = require('../middleware/requireAuth');
const { authLimiter } = require('../middleware/rateLimits');
const c = require('../controllers/authController');

router.post('/signup', authLimiter, c.signup);
router.post('/login', authLimiter, c.login);
router.post('/logout', c.logout);
router.get('/me', requireAuth, c.me);
router.patch('/preferences', requireAuth, c.updatePreferences);
router.delete('/account', requireAuth, c.deleteAccount);

module.exports = router;
