function notFound(req, res) {
  res.status(404).json({ error: `No route matches ${req.method} ${req.originalUrl}.` });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  // Mongoose schema validation -> first readable message
  if (err.name === 'ValidationError') {
    const [first] = Object.values(err.errors);
    return res.status(400).json({ error: first.message });
  }
  // Duplicate key on username or email
  if (err.code === 11000) {
    const field = Object.keys(err.keyPattern || {})[0] === 'email' ? 'email address' : 'call sign';
    return res.status(409).json({ error: `That ${field} is already registered.` });
  }
  if (err.name === 'CastError') {
    return res.status(400).json({ error: 'That record id is not valid.' });
  }

  console.error('[error]', err);
  const status = err.status || 500;
  res.status(status).json({
    error: status === 500 ? 'Something failed on the server. Try again.' : err.message,
  });
}

/** Wraps async handlers so a rejected promise reaches errorHandler. */
const asyncRoute = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

module.exports = { notFound, errorHandler, asyncRoute };
