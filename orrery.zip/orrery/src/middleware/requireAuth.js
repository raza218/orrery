/** Gate for every /api route that touches an observer's own records. */
module.exports = function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ error: 'Sign in to continue.' });
  }
  next();
};
