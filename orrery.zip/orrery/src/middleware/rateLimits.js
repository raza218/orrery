const rateLimit = require('express-rate-limit');

const shared = { standardHeaders: true, legacyHeaders: false };

// Blunt instrument against credential stuffing on the sign-in form.
const authLimiter = rateLimit({
  ...shared,
  windowMs: 15 * 60 * 1000,
  limit: 20,
  message: { error: 'Too many attempts. Wait 15 minutes and try again.' },
});

const apiLimiter = rateLimit({ ...shared, windowMs: 60 * 1000, limit: 240 });

module.exports = { authLimiter, apiLimiter };
