const session = require('express-session');
const MongoStore = require('connect-mongo');

/**
 * Sessions live in MongoDB rather than memory, so a restart or a second
 * server process does not sign everyone out.
 */
module.exports = function buildSession(env) {
  const days = Number(env.SESSION_DAYS || 14);
  const maxAge = days * 24 * 60 * 60 * 1000;

  return session({
    name: 'orrery.sid',
    secret: env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    rolling: true,
    store: MongoStore.create({ mongoUrl: env.MONGO_URI, ttl: maxAge / 1000, touchAfter: 3600 }),
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: env.NODE_ENV === 'production',
      maxAge,
    },
  });
};
