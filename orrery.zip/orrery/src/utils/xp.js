/**
 * Progression curve. Total XP required to *reach* level L is 50 * L * (L - 1),
 * so level 2 costs 100, level 3 costs 300, level 4 costs 600, and so on.
 */
const RANKS = [
  'Cadet', 'Observer', 'Navigator', 'Astronomer', 'Cartographer',
  'Astrographer', 'Commander', 'Voyager', 'Archivist of Stars',
];

const totalXpForLevel = (level) => 50 * level * (level - 1);

function levelFromXp(xp) {
  const safeXp = Math.max(0, Number(xp) || 0);
  // Solve 50L(L-1) <= xp for L.
  return Math.floor((1 + Math.sqrt(1 + safeXp / 12.5)) / 2);
}

function progress(xp) {
  const level = levelFromXp(xp);
  const floorXp = totalXpForLevel(level);
  const ceilXp = totalXpForLevel(level + 1);
  return {
    xp,
    level,
    rank: RANKS[Math.min(level - 1, RANKS.length - 1)],
    xpIntoLevel: xp - floorXp,
    xpForNextLevel: ceilXp - floorXp,
    percent: Math.round(((xp - floorXp) / (ceilXp - floorXp)) * 100),
  };
}

module.exports = { RANKS, totalXpForLevel, levelFromXp, progress };
