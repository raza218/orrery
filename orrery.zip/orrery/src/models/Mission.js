const mongoose = require('mongoose');

const XP_BY_DIFFICULTY = { routine: 10, standard: 25, deep: 60 };

const missionSchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: [true, 'Give the mission a name.'], trim: true, maxlength: 140 },
    difficulty: {
      type: String,
      enum: { values: Object.keys(XP_BY_DIFFICULTY), message: 'Unknown difficulty.' },
      default: 'standard',
    },
    completed: { type: Boolean, default: false },
    completedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

missionSchema.virtual('xpValue').get(function xpValue() {
  return XP_BY_DIFFICULTY[this.difficulty];
});

missionSchema.set('toJSON', { virtuals: true });
missionSchema.statics.XP_BY_DIFFICULTY = XP_BY_DIFFICULTY;

module.exports = mongoose.model('Mission', missionSchema);
