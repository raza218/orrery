const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const SALT_ROUNDS = 12;

/**
 * An observer account. A document written here is permanent: it survives
 * sign-out, server restarts and session expiry, and is only ever removed by
 * the owner through DELETE /api/auth/account.
 */
const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: [true, 'Pick a call sign.'],
      // Uniqueness comes from the collation index at the bottom of this file,
      // so that comparison is case-insensitive. Declaring it here too would
      // create a second, case-sensitive index.
      trim: true,
      minlength: [3, 'Call sign needs at least 3 characters.'],
      maxlength: [24, 'Call sign can be at most 24 characters.'],
      match: [/^[a-zA-Z0-9_.-]+$/, 'Call sign can use letters, numbers, dot, dash and underscore.'],
    },
    email: {
      type: String,
      required: [true, 'Add an email address.'],
      unique: true,
      trim: true,
      lowercase: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'That email address looks incomplete.'],
    },
    passwordHash: { type: String, required: true, select: false },

    // Progression
    xp: { type: Number, default: 0, min: 0 },

    // Preferences persisted per observer
    preferences: {
      scene: { type: String, default: 'nebula' },
      studyMinutes: { type: Number, default: 25, min: 1, max: 180 },
      breakMinutes: { type: Number, default: 5, min: 1, max: 60 },
      soundOn: { type: Boolean, default: true },
    },

    lastSeenAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// Case-insensitive uniqueness so "Vega" and "vega" cannot both exist.
userSchema.index({ username: 1 }, { unique: true, collation: { locale: 'en', strength: 2 } });

userSchema.methods.setPassword = async function setPassword(plain) {
  this.passwordHash = await bcrypt.hash(plain, SALT_ROUNDS);
};

userSchema.methods.verifyPassword = function verifyPassword(plain) {
  return bcrypt.compare(plain, this.passwordHash);
};

// Never let the hash leave the server, whatever a controller forgets.
userSchema.set('toJSON', {
  transform(_doc, ret) {
    delete ret.passwordHash;
    delete ret.__v;
    return ret;
  },
});

module.exports = mongoose.model('User', userSchema);
