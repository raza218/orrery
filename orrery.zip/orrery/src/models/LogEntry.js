const mongoose = require('mongoose');

/** A pinned observation note. Position is stored so the board looks the same on any device. */
const logEntrySchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    body: { type: String, default: '', maxlength: 2000 },
    tint: { type: String, enum: ['amber', 'cyan', 'violet'], default: 'amber' },
    x: { type: Number, default: 40 },
    y: { type: Number, default: 40 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('LogEntry', logEntrySchema);
