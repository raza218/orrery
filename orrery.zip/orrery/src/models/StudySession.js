const mongoose = require('mongoose');

/** One completed focus block. The raw material for the analytics panel. */
const studySessionSchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    minutes: { type: Number, required: true, min: 1, max: 180 },
    scene: { type: String, default: 'nebula' },
    endedAt: { type: Date, default: Date.now, index: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('StudySession', studySessionSchema);
