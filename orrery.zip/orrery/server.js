require('dotenv').config();

const path = require('path');
const express = require('express');
const helmet = require('helmet');

const { connectDatabase } = require('./src/config/db');
const buildSession = require('./src/config/session');
const { apiLimiter } = require('./src/middleware/rateLimits');
const { notFound, errorHandler } = require('./src/middleware/errorHandler');
const apiRoutes = require('./src/routes');

const REQUIRED = ['MONGO_URI', 'SESSION_SECRET'];
const missing = REQUIRED.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`[config] missing in .env: ${missing.join(', ')}. Copy .env.example to .env first.`);
  process.exit(1);
}

const app = express();
const PORT = process.env.PORT || 3000;

app.set('trust proxy', 1);
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com'],
        imgSrc: ["'self'", 'data:'],
        scriptSrc: ["'self'"],
      },
    },
  })
);
app.use(express.json({ limit: '64kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(buildSession(process.env));

app.use('/api', apiLimiter, apiRoutes);
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.use(notFound);
app.use(errorHandler);

connectDatabase(process.env.MONGO_URI)
  .then(() => {
    app.listen(PORT, () => console.log(`[orrery] listening on http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('[db] could not connect:', err.message);
    process.exit(1);
  });
